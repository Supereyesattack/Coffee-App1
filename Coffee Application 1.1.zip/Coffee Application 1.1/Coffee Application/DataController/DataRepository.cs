using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using System.Json;
using System.Net.Http.Headers;
//using System.Dynamic;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

//using Xamarin.Auth;
using Coffee_Application.DataModel;

using Salesforce.Common;
using Salesforce.Force;
using Salesforce.Common.Models;

namespace Coffee_Application.DataController
{
    class DataRepository
    {
        private static string securityToken = "Dx38jJmkBOpamzmF8QWmg9t0";
        private static string consumerKey = "3MVG9fMtCkV6eLhfrqYgIEUifLDXx6ztdUXjsHXkVDL81lmI7ZYlmmPG0We1mJYBQlq5yl3_doyZKXWgoVpVs";
        private static string consumerSecret = "8718126830326927672";
        private static string username = "docampo@shaw.ca";
        private static string password = "dlanyert2z0n6" + securityToken;
        private static string url = "https://login.salesforce.com/services/oauth2/token";

        private static List<Store> storeList = new List<Store>();
        private static List<StoreProduct> storeProductList = new List<StoreProduct>();
        private static List<CustomerFavoriteProduct> customerFavoriteProductList = new List<CustomerFavoriteProduct>();
        private static List<CustomerOrder> customerOrderList = new List<CustomerOrder>();
        private static List<LoginUser> loginUserList = new List<LoginUser>();
        private static ExceptionMessage exceptionMessage = new ExceptionMessage();

        //private static HttpClient authClient = new HttpClient();
        private static AuthenticationClient authClient = new AuthenticationClient();

        /*
        public async void Setup()
		{
            //Authenticating REST Users
            HttpContent content = new FormUrlEncodedContent(new Dictionary<String, String>
                    {
                        {"grant_type", "password"},
                        {"client_id", consumerKey},
                        {"client_secret", consumerSecret},
                        {"username", username},
                        {"password", password + securityToken}
                    }
                );

            HttpResponseMessage message = await authClient.PostAsync(url, content);

            var responseString = await message.Content.ReadAsStringAsync();
  
            System.Diagnostics.Debug.WriteLine("responseString: {0}", responseString);

            var json = JsonValue.Parse(@responseString);
            string oauthToken = json["access_token"];
            string serviceUrl = json["instance_url"];

            HttpClient httpClient = new HttpClient();

            string uri = serviceUrl + "/services/data/v25.0/sobjects/Customer_Order__c/";

            string insertPacket = "{\"Account__c\":\"001j000000JKpCoAAL\", \"Contact__c\":\"003j000000CsgBKAAZ\"}";

            StringContent insertString = new StringContent(insertPacket, Encoding.UTF8, "application/json");

            //create request message associated with POST verb
            HttpRequestMessage requestMessage = new HttpRequestMessage(System.Net.Http.HttpMethod.Post, uri);

            //add token to header
            requestMessage.Headers.Add("Authorization", "OAuth " + oauthToken);

            //return xml to the caller
            requestMessage.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            requestMessage.Content = insertString;

            HttpResponseMessage responseMessage = await httpClient.SendAsync(requestMessage);
            string result = await responseMessage.Content.ReadAsStringAsync();

            System.Diagnostics.Debug.WriteLine("Result: {0} Press [Enter] to continue ...", result);
            
            // --
            var client = new SalesforceClient(consumerKey, consumerSecret, redirectUrl);

            var users = client.LoadUsers();

            if (!users.Any())
            {
                client.AuthenticationComplete += (sender, e) => OnAuthenticationCompleted(e);

                // Starts the Salesforce login process.
                var loginUI = client.GetLoginInterface();
                //DisplayThe(loginUI);
            }
            else
            {
                // We're ready to fetch some data!
                // Let's grab some sales accounts to display.
                //IEnumerable<SObject> results =
                //    await client.ReadAsync("SELECT Name, AccountNumber FROM Account");

                var request = new ReadRequest {
                    Resource = new Search { QueryText = "FIND {John}" }
                };

                var results = await client.ProcessAsync<ReadRequest> (request);

                //DoSomethingAmazingWith(results);
            }
            //--
		}
        */

        private static async Task RunCustomerOrders_Create(ForceClient client, List<CustomerOrder> customerOrder)
        {
            // Authenticate with Salesforce
            //await authClient.UsernamePasswordAsync(consumerKey, consumerSecret, username, password, url);
            //var client = new ForceClient(authClient.InstanceUrl, authClient.AccessToken, authClient.ApiVersion);

            /*
            public const String SObjectTypeName = "Customer_Order__c";
            public String Id { get; set; }
            public String Name { get; set; }
            public String Account__c { get; set; }
            public String Contact__c { get; set; }
            public List<CustomerOrderItem> CustomerOrderItem { get; set; }
            */

            var order = new CustomerOrder() { Account__c = "001j000000JKpCoAAL", Contact__c = "003j000000CsgBKAAZ" };

            try
            {
                var id = await client.CreateAsync("Customer_Order__c", order);
                Console.WriteLine("id = {0}", id);
            }
            catch (Exception e)
            {
                exceptionMessage.WriteException(e);
            }

        }

        private static async Task RunStores(string soqlString)
        {
            // Authenticate with Salesforce
            await authClient.UsernamePasswordAsync(consumerKey, consumerSecret, username, password, url);
            var client = new ForceClient(authClient.InstanceUrl, authClient.AccessToken, authClient.ApiVersion);

            QueryResult<Store> results = await client.QueryAsync<Store>(soqlString);

            storeList.AddRange(results.records);

            var nextRecordsUrl = results.nextRecordsUrl;

            if (!string.IsNullOrEmpty(nextRecordsUrl))
            {
                while (true)
                {
                    QueryResult<Store> continuationResults = await client.QueryContinuationAsync<Store>(nextRecordsUrl);

                    storeList.AddRange(continuationResults.records);

                    if (string.IsNullOrEmpty(continuationResults.nextRecordsUrl)) break;

                    //pass nextRecordsUrl back to client.QueryAsync to request next set of records                    
                    nextRecordsUrl = continuationResults.nextRecordsUrl;
                }
            }
        }

        private static async Task RunStoreProducts(string soqlString)
        {
            // Authenticate with Salesforce
            await authClient.UsernamePasswordAsync(consumerKey, consumerSecret, username, password, url);
            var client = new ForceClient(authClient.InstanceUrl, authClient.AccessToken, authClient.ApiVersion);

            QueryResult<StoreProduct> results = await client.QueryAsync<StoreProduct>(soqlString);

            storeProductList.AddRange(results.records);

            var nextRecordsUrl = results.nextRecordsUrl;

            if (!string.IsNullOrEmpty(nextRecordsUrl))
            {
                while (true)
                {
                    QueryResult<StoreProduct> continuationResults = await client.QueryContinuationAsync<StoreProduct>(nextRecordsUrl);

                    storeProductList.AddRange(continuationResults.records);

                    if (string.IsNullOrEmpty(continuationResults.nextRecordsUrl)) break;

                    //pass nextRecordsUrl back to client.QueryAsync to request next set of records                    
                    nextRecordsUrl = continuationResults.nextRecordsUrl;
                }
            }
        }

        private static async Task RunCustomerFavoriteProducts(string soqlString)
        {
            // Authenticate with Salesforce
            await authClient.UsernamePasswordAsync(consumerKey, consumerSecret, username, password, url);
            var client = new ForceClient(authClient.InstanceUrl, authClient.AccessToken, authClient.ApiVersion);

            QueryResult<CustomerFavoriteProduct> results = await client.QueryAsync<CustomerFavoriteProduct>(soqlString);

            customerFavoriteProductList.AddRange(results.records);

            var nextRecordsUrl = results.nextRecordsUrl;

            if (!string.IsNullOrEmpty(nextRecordsUrl))
            {
                while (true)
                {
                    QueryResult<CustomerFavoriteProduct> continuationResults = await client.QueryContinuationAsync<CustomerFavoriteProduct>(nextRecordsUrl);

                    customerFavoriteProductList.AddRange(continuationResults.records);

                    if (string.IsNullOrEmpty(continuationResults.nextRecordsUrl)) break;

                    //pass nextRecordsUrl back to client.QueryAsync to request next set of records                    
                    nextRecordsUrl = continuationResults.nextRecordsUrl;
                }
            }
        }
       
        private static async void RunLoginUser(ForceClient client, string username, string soqlString)
        {
            // Authenticate with Salesforce
            //await authClient.UsernamePasswordAsync(consumerKey, consumerSecret, username, password, url);
            //var client = new ForceClient(authClient.InstanceUrl, authClient.AccessToken, authClient.ApiVersion);

            QueryResult<LoginUser> results = await client.QueryAsync<LoginUser>(soqlString);

            loginUserList.AddRange(results.records);

            var nextRecordsUrl = results.nextRecordsUrl;

            if (!string.IsNullOrEmpty(nextRecordsUrl))
            {
                while (true)
                {
                    QueryResult<LoginUser> continuationResults = await client.QueryContinuationAsync<LoginUser>(nextRecordsUrl);

                    loginUserList.AddRange(continuationResults.records);

                    if (string.IsNullOrEmpty(continuationResults.nextRecordsUrl)) break;

                    //pass nextRecordsUrl back to client.QueryAsync to request next set of records                    
                    nextRecordsUrl = continuationResults.nextRecordsUrl;
                }
            }
        }

        /*
        // this code currently does not work, the List<T> list is readonly
        private static async Task RunDataQuery<T>(List<T> list, string query)
        {
            // Authenticate with Salesforce
            await authClient.UsernamePasswordAsync(ConsumerKey, ConsumerSecret, Username, Password, ".net-api-client", url);
            var client = new ForceClient(authClient.InstanceUrl, authClient.AccessToken, authClient.ApiVersion);

            // using dynamic
            var entity = await client.QueryAsync<dynamic>(query);

            // Selecting multiple records into a dynamic object
            foreach (dynamic record in entity.records)
                list.AddRange(record);
        }
        */

        public List<Store> GetStores(string accountParentId)
        {
            try
            {
                storeList.Clear();
                var runAccounts = RunStores(string.Format("SELECT Id, Name, ParentId FROM Account WHERE ParentId = '{0}'", accountParentId));
                runAccounts.Wait();
            }
            catch (Exception e)
            {
                exceptionMessage.WriteException(e);
            }
            return storeList;
        }

        public List<StoreProduct> GetStoreProducts(string storeId)
        {
            try
            {
                storeProductList.Clear();
                var runStoreProducts = RunStoreProducts(string.Format("SELECT Id, Family, Name, Description, Price__c, Account__c, Reward__c FROM Product2 WHERE IsActive = True AND Account__c = '{0}'", storeId));
                runStoreProducts.Wait();
            }
            catch (Exception e)
            {
                exceptionMessage.WriteException(e);
            }

            return storeProductList;
        }

        public List<CustomerFavoriteProduct> GetCustomerFavoriteProducts(string customerId)
        {
            try
            {
                customerFavoriteProductList.Clear();
                var runCustomerFavoriteProducts = RunCustomerFavoriteProducts(string.Format("SELECT Id, Product_Name__c, Customer__c, Product__c FROM Favorite_Product__c WHERE Customer__c = '{0}'", customerId));
                //runCustomerFavoriteProducts.Wait();
            }
            catch (Exception e)
            {
                exceptionMessage.WriteException(e);
            }

            return customerFavoriteProductList;
        }

        /*

                Task<bool> clientTask = AuthenticateClient(username, password);

                FindViewById<TextView>(Resource.Id.ResultTextView).Text = "authenticating...";
                FindViewById<TextView>(Resource.Id.ResultEditText).Text = "authenticating...";

                // await! control returns to the caller
                bool clientIsAuthenticated = await clientTask;
        */

        /*
        public async Task<List<string>> Testing()
        {
            var uri1 = new Uri("http://www.google.com");
            using (var httpClient = new HttpClient())
            {
                var response = await httpClient.GetAsync(uri1);
                return (await response.Content.ReadAsAsync<List<string>>());
            }
        }
        */

        public async Task<List<CustomerOrder>> SetCustomerOrders(ForceClient client, List<CustomerOrder> customerOrder)
        {
            customerOrderList.Clear();

            try
            {
                var runCustomerOrders = RunCustomerOrders_Create(client, customerOrder);
                await runCustomerOrders;
            }
            catch (Exception e)
            {
                exceptionMessage.WriteException(e);
            }

            return customerOrderList;
        }

        public List<LoginUser> GetLoginUser(ForceClient client, string userName)
        {
            try
            {
                loginUserList.Clear();
                RunLoginUser(client, userName, string.Format("SELECT Id, Name, Username, Total_Rewards__c, Street, City, State, PostalCode, Country, Email, Phone FROM User WHERE Username = '{0}'", userName));
            }
            catch (Exception e)
            {
                exceptionMessage.WriteException(e);
            }

            return loginUserList;
        }
    }
}