using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Newtonsoft.Json;
using Coffee_Application.DataModel;

namespace Coffee_Application
{
    [Activity(Label = "ProductList")]
    public class ProductActivity : Activity
    {
        public CustomProductListAdapter listAdapter;
        public List<CustomerOrderItem> customerOrderItems = new List<CustomerOrderItem>();

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            int totalQuantityOrdered = 0;

            string accountId = Intent.GetStringExtra("AccountId") ?? null;
            string json = Intent.GetStringExtra("StoreProductData") ?? null;
            List<CustomProductList> items = new List<CustomProductList>();

            if (json != null)
            {
                // convert json string back to a list object
                var productList = JsonConvert.DeserializeObject<List<StoreProduct>>(json);

                for (int i = 0; i < productList.Count; i++)
                {
                    CustomProductList item = new CustomProductList();
                    item.Name = productList[i].Name;
                    item.Price = productList[i].Price__c;
                    item.Id = productList[i].Id;
                    items.Add(item);
                }
            }

            // Create your application here
            SetContentView(Resource.Layout.ProductList);

            //Create our adapter
            listAdapter = new CustomProductListAdapter(this, items);

            //Find the listview reference
            var listView = FindViewById<ListView>(Resource.Id.ProductListView);

            //Hook up our adapter to our ListView
            listView.Adapter = listAdapter;

            // Get our button from the layout resource,
            // and attach an event to it
            Button viewOrderBagButton = FindViewById<Button>(Resource.Id.ViewOrderBagButton);
            viewOrderBagButton.Enabled = false;

            viewOrderBagButton.Click += delegate
            {
                if (customerOrderItems.Count > 0)
                {
                    string jsonOrderBag = JsonConvert.SerializeObject(customerOrderItems);

                    Intent intent = new Intent(this, typeof(OrderBagActivity));
                    intent.PutExtra("AccountId", accountId);
                    intent.PutExtra("OrderBagData", jsonOrderBag);
                    StartActivity(intent);
                }
                else
                    Toast.MakeText(this, "Your order bag is empty!", ToastLength.Short).Show();
            };

            //Wire up the click event
            listView.ItemClick += (sender, e) =>
            {
                totalQuantityOrdered++;

                //Get our item from the list adapter
                CustomProductList item = (CustomProductList)listAdapter.GetItemAtPosition(e.Position);

                var index = customerOrderItems.FindIndex(r => r.Account_Product__c == item.Id);

                if (index >= 0)
                {
                    customerOrderItems[index].Quantity__c++;
                    customerOrderItems[index].Reward__c = customerOrderItems[index].Reward__c + item.Reward;
                }
                else
                {
                    customerOrderItems.Add
                        (
                            new CustomerOrderItem()
                            {
                                Account_Product__c = item.Id,
                                Product_Name__c = item.Name,
                                Unit_Price__c = item.Price,
                                Quantity__c = 1,
                                Reward__c = item.Reward
                            }
                        );

                    viewOrderBagButton.Text = "View Order Bag [" + totalQuantityOrdered.ToString() + "]";

                    index = 0;
                }

                viewOrderBagButton.Enabled = true;

                Toast.MakeText(this, "Ordered: " + customerOrderItems[index].Product_Name__c + " Qty: " + customerOrderItems[index].Quantity__c, ToastLength.Short).Show();
            };
        }
    }
}