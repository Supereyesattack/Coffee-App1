using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Graphics.Drawables;

using Newtonsoft.Json;
using Coffee_Application.DataModel;
using Salesforce.Common.Models;


//this.ActionBar.SetDisplayShowHomeEnabled (false);
//this.ActionBar.SetDisplayShowTitleEnabled (false);


namespace Coffee_Application
{
    [Activity(Label = "University Of Calgary - Coffee Shops")]
    public class VendorActivity : Activity
    {
        public CustomListAdapter listAdapter;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            string jsonVendor = Intent.GetStringExtra("VendorData") ?? null;
            List<CustomList> items = new List<CustomList>();

            if (jsonVendor != null)
            {
                // convert json string back to a list object
                var storeList = JsonConvert.DeserializeObject<List<Store>>(jsonVendor);
                
                for (int i = 0; i < storeList.Count; i++)
                {
                    CustomList item = new CustomList();
                    item.Name = storeList[i].Name;
                    item.Id = storeList[i].Id;
                    //item.Image = Resource.Drawable.Icon;
                    items.Add(item);
                }
            }

            /*
            RequestWindowFeature(WindowFeatures.ActionBar);
            ActionBar.NavigationMode = ActionBarNavigationMode.Tabs;
            */

            SetContentView(Resource.Layout.VendorList);

            /*
            // Start creation of Tabs
            ActionBar.Tab tab = ActionBar.NewTab();

            tab.SetText(Resources.GetString(Resource.String.Vendor));
            //tab.SetIcon(Resource.Drawable.Favorite);
            tab.TabSelected += (sender, args) =>
            {
                // Do something when tab is selected
            };
            ActionBar.AddTab(tab);

            tab = ActionBar.NewTab();
            tab.SetText(Resources.GetString(Resource.String.Profile));
            //tab.SetIcon(Resource.Drawable.Profile);
            tab.TabSelected += (sender, args) => 
            {
                                    // Do something when tab is selected
            };
            ActionBar.AddTab(tab);
            // End creation of Tabs
            */

            //Create our adapter
            listAdapter = new CustomListAdapter(this, items);

            //Find the listview reference
            var listView = FindViewById<ListView>(Resource.Id.VendorListView);

            //Hook up our adapter to our ListView
            listView.Adapter = listAdapter;

            //Wire up the click event
            listView.ItemClick += async (sender, e) =>
            {
                //Get our item from the list adapter
                var item = this.listAdapter.GetItemAtPosition(e.Position);

                //Make a toast with the item name just to show it was clicked
                //Toast.MakeText(this, "Name: " +item.Name + " Id: " + item.Id + " Clicked!", ToastLength.Short).Show();

                // pass list object in the form of json string

                //
                var forceClient = Global.ForceClient;

                
                var soqlStoreString = string.Format("SELECT Id, Name, ParentId FROM Account WHERE ParentId = '{0}'", item.Id);

                List<Store> storeList = new List<Store>();

                // Retrieve stores from Salesforce
                QueryResult<Store> results1 = await forceClient.QueryAsync<Store>(soqlStoreString);

                storeList.AddRange(results1.records);

                var nextRecordsUrl = results1.nextRecordsUrl;

                if (!string.IsNullOrEmpty(nextRecordsUrl))
                {
                    while (true)
                    {
                        QueryResult<Store> continuationResults = await forceClient.QueryContinuationAsync<Store>(nextRecordsUrl);

                        storeList.AddRange(continuationResults.records);

                        if (string.IsNullOrEmpty(continuationResults.nextRecordsUrl)) break;

                        //pass nextRecordsUrl back to client.QueryAsync to request next set of records                    
                        nextRecordsUrl = continuationResults.nextRecordsUrl;
                    }
                }
                //

                string jsonLocation = JsonConvert.SerializeObject(storeList);

                Intent intent = new Intent(this, typeof(LocationActivity));
                intent.PutExtra("LocationData", jsonLocation);
                StartActivity(intent);
            };
        }

        /*
        void listView_ItemClick(object sender, AdapterView.ItemClickEventArgs e)
        {
            //Get our item from the list adapter
            var item = this.listAdapter.GetItemAtPosition(e.Position);

            //Make a toast with the item name just to show it was clicked
            //Toast.MakeText(this, "Name: " +item.Name + " Id: " + item.Id + " Clicked!", ToastLength.Short).Show();

            // pass list object in the form of json string

            //

            var forceClient = Global.ForceClient;

            var soqlStoreString = string.Format("SELECT Id, Name, ParentId FROM Account WHERE ParentId = '' AND Industry = 'Food & Beverage'");

            List<Store> storeList = new List<Store>();

            // Retrieve stores from Salesforce
            QueryResult<Store> results1 = await forceClient.QueryAsync<Store>(soqlStoreString);

            storeList.AddRange(results1.records);

            var nextRecordsUrl = results1.nextRecordsUrl;

            if (!string.IsNullOrEmpty(nextRecordsUrl))
            {
                while (true)
                {
                    QueryResult<Store> continuationResults = await forceClient.QueryContinuationAsync<Store>(nextRecordsUrl);

                    storeList.AddRange(continuationResults.records);

                    if (string.IsNullOrEmpty(continuationResults.nextRecordsUrl)) break;

                    //pass nextRecordsUrl back to client.QueryAsync to request next set of records                    
                    nextRecordsUrl = continuationResults.nextRecordsUrl;
                }
            }
            //

            string json = JsonConvert.SerializeObject(storeList);

            Intent intent = new Intent(this, typeof(LocationActivity));
            intent.PutExtra("LocationData", json);
            StartActivity(intent);
        }
       */
    }
}