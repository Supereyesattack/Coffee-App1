using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Coffee_Application.DataModel;

namespace Coffee_Application.DataModel
{
    public class CustomListAdapter : BaseAdapter
    {
        Activity context;

        public List<CustomList> items = new List<CustomList>();

        public CustomListAdapter(Activity context, List<CustomList> data) //We need a context to inflate our row view from
            : base()
        {
            this.context = context;

            for (int i = 0; i < data.Count; i++)
            {
                CustomList item = new CustomList();
                item.Name = data[i].Name;
                item.Id = data[i].Id;
                //item.Image = Resource.Drawable.Icon;
                items.Add(item);
            }
        }

        public override int Count
        {
            get { return items.Count; }
        }

        public override Java.Lang.Object GetItem(int position)
        {
            return position;
        }

        public override long GetItemId(int position)
        {
            return position;
        }

        public override View GetView(int position, View convertView, ViewGroup parent)
        {
            //Get our object for this position
            var item = items[position];

            //Try to reuse convertView if it's not  null, otherwise inflate it from our item layout
            // This gives us some performance gains by not always inflating a new view
            // This will sound familiar to MonoTouch developers with UITableViewCell.DequeueReusableCell()
            var view = (convertView ??
                context.LayoutInflater.Inflate(
                    Resource.Layout.CustomListItem,
                    parent,
                    false)) as LinearLayout;

            //Find references to each subview in the list item's view
            var imageItem = view.FindViewById(Resource.Id.ItemImageView) as ImageView;
            //var textTop = view.FindViewById(Resource.Id.TopTextView) as TextView;
            var textBottom = view.FindViewById(Resource.Id.BottomTextView) as TextView;

            //Assign this item's values to the various subviews
            //imageItem.SetImageResource(item.Image);
            //textTop.SetText(item.Name, TextView.BufferType.Normal);
            textBottom.SetText(item.Name, TextView.BufferType.Normal);

            //Finally return the view
            return view;
        }

        public CustomList GetItemAtPosition(int position)
        {
            return items[position];
        }
    }
}