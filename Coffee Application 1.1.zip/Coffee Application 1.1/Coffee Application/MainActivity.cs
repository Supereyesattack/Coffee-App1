﻿using System;
using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;

using Coffee_Application.DataModel;
using System.Collections.Generic;
using System.Threading.Tasks;

using System.Net.Http;
using Newtonsoft.Json;

// Force.com Toolkit for .NET https://github.com/developerforce/Force.com-Toolkit-for-NET
using Salesforce.Force;
using Salesforce.Common;
using Salesforce.Common.Models;

namespace Coffee_Application
{
    [Activity(Label = "University Of Calgary - Coffee Shops", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        private static string consumerKey = "3MVG9fMtCkV6eLhfrqYgIEUifLDXx6ztdUXjsHXkVDL81lmI7ZYlmmPG0We1mJYBQlq5yl3_doyZKXWgoVpVs";
        private static string consumerSecret = "8718126830326927672";
        private static string url = "https://login.salesforce.com/services/oauth2/token";
        private static AuthenticationClient authClient = new AuthenticationClient();

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.Main);
            
            Button authenticate = FindViewById<Button>(Resource.Id.AuthenticateButton);
            authenticate.Click += async (sender, e) =>
            {
                string username = "docampo@shaw.ca";
                string password = "dlanyert2z0n6";

                FindViewById<TextView>(Resource.Id.UsernameEditText).Text = username;
                FindViewById<TextView>(Resource.Id.PasswordEditText).Text = password;

                //string username = FindViewById<TextView>(Resource.Id.UsernameEditText).Text;
                //string password = FindViewById<TextView>(Resource.Id.PasswordEditText).Text;

                Task<bool> clientTask = AuthenticateClient(username, password);

                FindViewById<TextView>(Resource.Id.ResultTextView).Text = "authenticating...";
                FindViewById<TextView>(Resource.Id.ResultEditText).Text = "authenticating...";

                // await! control returns to the caller
                bool clientIsAuthenticated = await clientTask;

                // when the Task<ForceClient> returns, the value is available and we can display on the UI
                FindViewById<TextView>(Resource.Id.ResultTextView).Text = "Authenticated: " + clientIsAuthenticated;

                if (clientIsAuthenticated && authClient.Id != null)
                {

                    //ForceClient forceClient = new ForceClient(authClient.InstanceUrl, authClient.AccessToken, authClient.ApiVersion, new HttpClient());
                    ForceClient forceClient = new ForceClient(authClient.InstanceUrl, authClient.AccessToken, authClient.ApiVersion);

                    var soqlLoginString = string.Format("SELECT Id, Name, Username, Total_Rewards__c, Street, City, State, PostalCode, Country, Email, Phone FROM User WHERE Username = '{0}'", username);
                    List<LoginUser> loginUserList = new List<LoginUser>();

                    try
                    {
                        // Retrieve the login user info from Salesforce
                        QueryResult<LoginUser> results = await forceClient.QueryAsync<LoginUser>(soqlLoginString);

                        FindViewById<TextView>(Resource.Id.ResultEditText).Text += "Client is querying records...";

                        loginUserList.AddRange(results.records);

                        var nextRecordsUrl = results.nextRecordsUrl;

                        if (!string.IsNullOrEmpty(nextRecordsUrl))
                        {
                            while (true)
                            {
                                QueryResult<LoginUser> continuationResults = await forceClient.QueryContinuationAsync<LoginUser>(nextRecordsUrl);

                                FindViewById<TextView>(Resource.Id.ResultEditText).Text += "Client is querying more records...";

                                loginUserList.AddRange(continuationResults.records);

                                if (string.IsNullOrEmpty(continuationResults.nextRecordsUrl)) break;

                                //pass nextRecordsUrl back to client.QueryAsync to request next set of records                    
                                nextRecordsUrl = continuationResults.nextRecordsUrl;
                            }
                        }
                    }
                    catch (Exception exception)
                    {
                        FindViewById<TextView>(Resource.Id.ResultEditText).Text = "Client error..." + exception.ToString();
                    }

                    if (loginUserList.Count > 0)
                    {

                        var soqlStoreString = string.Format("SELECT Id, Name, ParentId FROM Account WHERE ParentId = '' AND Industry = 'Food & Beverage'");

                        List<Store> storeList = new List<Store>();

                        // Retrieve stores from Salesforce
                        QueryResult<Store> results1 = await forceClient.QueryAsync<Store>(soqlStoreString);

                        storeList.AddRange(results1.records);

                        var nextRecordsUrl = results1.nextRecordsUrl;

                        if (!string.IsNullOrEmpty(nextRecordsUrl))
                        {
                            while (true)
                            {
                                QueryResult<Store> continuationResults = await forceClient.QueryContinuationAsync<Store>(nextRecordsUrl);

                                storeList.AddRange(continuationResults.records);

                                if (string.IsNullOrEmpty(continuationResults.nextRecordsUrl)) break;

                                //pass nextRecordsUrl back to client.QueryAsync to request next set of records                    
                                nextRecordsUrl = continuationResults.nextRecordsUrl;
                            }
                        }

                        if (storeList.Count > 0)
                        {
                            Global.UserId = loginUserList[0].Id;
                            Global.Name = loginUserList[0].Name;
                            Global.ForceClient = forceClient;

                            // pass list object in the form of json string
                            string json = JsonConvert.SerializeObject(storeList);

                            Intent intent = new Intent(this, typeof(VendorActivity));
                            intent.PutExtra("VendorData", json);
                            StartActivity(intent);
                        }
                    }
                }

                // "returns" void, since it's an event handler
            };
        }

        public async Task<bool> AuthenticateClient(string username, string password)
        {
            TextView resultEditText = FindViewById<TextView>(Resource.Id.ResultEditText);

            //create auth client to retrieve token
            var authTask = authClient.UsernamePasswordAsync(consumerKey, consumerSecret, username, password, url);
            try
            {
                await authTask;

                resultEditText.Text += "AuthenticateClient method continues after async call. . . . .\n";
                resultEditText.Text += "Authenticated the Salesforce client.\n\n\n";

                return true;
            }
            catch (Exception e)
            {
                resultEditText.Text += "AuthenticateClient method error. . . . .\n" + e.ToString();

                return false;
            }            
        }

    }

    public static class Global
    {
        public static string UserId { get; set; }
        public static string Name { get; set; }
        public static ForceClient ForceClient { get; set; }
    }
}