﻿/* Screen     : User Authentication
*  Description: This will authenticate the application and let user logs in to Salesforce
*/

using System;
using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;

using Coffee_Application.DataModel;
using System.Collections.Generic;
using System.Threading.Tasks;

using System.Net.Http;
using Newtonsoft.Json;

// Force.com Toolkit for .NET https://github.com/developerforce/Force.com-Toolkit-for-NET
using Salesforce.Force;
using Salesforce.Common;
using Salesforce.Common.Models;

namespace Coffee_Application
{
    [Activity(Label = "@string/ApplicationName", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        
        // The following are from Salesforce configuration, needed for authentication
        // This is using OAuth Authentication
        private static string consumerKey = "3MVG9fMtCkV6eLhfrqYgIEUifLDXx6ztdUXjsHXkVDL81lmI7ZYlmmPG0We1mJYBQlq5yl3_doyZKXWgoVpVs";
        private static string consumerSecret = "8718126830326927672";
        private static string url = "https://login.salesforce.com/services/oauth2/token";
        //

        private static AuthenticationClient authClient = new AuthenticationClient();

        // This will authenticate the application and let user logs in to Salesforce
        // On success, it will query the stores from Salesforce
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.Main);

            Button authenticate = FindViewById<Button>(Resource.Id.LoginButton);

            authenticate.Click += async (sender, e) =>
            {
                // remove these 2 lines before deployment, the following are only for testing purposes
                FindViewById<TextView>(Resource.Id.UsernameEditText).Text = "docampo@shaw.ca";
                FindViewById<TextView>(Resource.Id.PasswordEditText).Text = "dlanyert2z0n6";

                var resultTextView = FindViewById<TextView>(Resource.Id.ResultTextView);

                string username = FindViewById<TextView>(Resource.Id.UsernameEditText).Text;
                string password = FindViewById<TextView>(Resource.Id.PasswordEditText).Text;

                if (username.Trim() == "" || password.Trim() == "")
                    resultTextView.Text = "Invalid Username or Password!";
                else
                {
                    authenticate.Enabled = false;
                    authenticate.Clickable = false;

                    Task<bool> clientTask = AuthenticateClient(username, password);

                    resultTextView.Text = "Authenticating application...";

                    // await! control returns to the caller
                    bool clientIsAuthenticated = await clientTask;

                    if (clientIsAuthenticated && authClient.Id != null)
                    {
                        //resultTextView.Text = "Loading application...";

                        ForceClient forceClient = new ForceClient(authClient.InstanceUrl, authClient.AccessToken, authClient.ApiVersion);

                        var soqlLoginString = string.Format("SELECT Id, Name, Username, Total_Rewards__c, Street, City, State, PostalCode, Country, Email, Phone FROM User WHERE Username = '{0}'", username);
                        List<LoginUser> loginUserList = new List<LoginUser>();

                        try
                        {
                            // Retrieve the login user info from Salesforce
                            QueryResult<LoginUser> results = await forceClient.QueryAsync<LoginUser>(soqlLoginString);

                            loginUserList.AddRange(results.records);

                            var nextRecordsUrl = results.nextRecordsUrl;

                            if (!string.IsNullOrEmpty(nextRecordsUrl))
                            {
                                while (true)
                                {
                                    QueryResult<LoginUser> continuationResults = await forceClient.QueryContinuationAsync<LoginUser>(nextRecordsUrl);

                                    loginUserList.AddRange(continuationResults.records);

                                    if (string.IsNullOrEmpty(continuationResults.nextRecordsUrl)) break;

                                    //pass nextRecordsUrl back to client.QueryAsync to request next set of records                    
                                    nextRecordsUrl = continuationResults.nextRecordsUrl;
                                }
                            }
                        }
                        catch (Exception)
                        {
                            resultTextView.Text = "Loading error! Please try again.";
                        }

                        if (loginUserList.Count > 0)
                        {
                            Global.UserId = loginUserList[0].Id;
                            Global.Name = loginUserList[0].Name;
                            Global.ForceClient = forceClient;

                            Intent intent = new Intent(this, typeof(MenuSelectionActivity));
                            StartActivity(intent);
                        }
                        else
                            resultTextView.Text = "Invalid Username or Password!";
                    }
                    else
                    {
                        resultTextView.Text = "Failed to authenticate application! Please try again.";
                        authenticate.Enabled = true;
                        authenticate.Clickable = true;
                    }
                }
            };
        }

        // This is the method that calls for authentication
        public async Task<bool> AuthenticateClient(string username, string password)
        {
            //create auth client to retrieve token
            var authTask = authClient.UsernamePasswordAsync(consumerKey, consumerSecret, username, password, url);
            try
            {
                await authTask;
                return true;
            }
            catch (Exception)
            {
                return false;
            }            
        }

    }

    public static class Global
    {
        public static string UserId { get; set; }
        public static string Name { get; set; }
        public static ForceClient ForceClient { get; set; }
    }
}