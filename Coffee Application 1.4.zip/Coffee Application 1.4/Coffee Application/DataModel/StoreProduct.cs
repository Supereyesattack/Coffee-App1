/* Class: List of Products
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace Coffee_Application.DataModel
{
    public class StoreProduct : ProductCategory
    {
        public String Id { get; set; }
        public String Name { get; set; }
        public String Description__c { get; set; }
        public Decimal Price__c { get; set; }
        public Decimal Reward__c { get; set; }        
    }
}