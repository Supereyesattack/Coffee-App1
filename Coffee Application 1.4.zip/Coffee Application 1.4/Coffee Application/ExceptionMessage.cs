using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace Coffee_Application
{
    class ExceptionMessage
    {
        public void WriteException(Exception e)
        {
            Console.WriteLine(e.Message);
            Console.WriteLine(e.StackTrace);
            var innerException = e.InnerException;
            while (innerException != null)
            {
                Console.WriteLine(innerException.Message);
                Console.WriteLine(innerException.StackTrace);
                innerException = innerException.InnerException;
            }
        }
    }
}