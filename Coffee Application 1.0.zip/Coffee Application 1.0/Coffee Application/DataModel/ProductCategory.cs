using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace Coffee_Application.DataModel
{
    public class ProductCategory
    {
        public const String SObjectTypeName = "Account_Product__c";
        public String Account__c { get; set; }
        public String Family__c { get; set; }
    }
}