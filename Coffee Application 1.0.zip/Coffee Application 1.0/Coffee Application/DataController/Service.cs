using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

using Coffee_Application.DataModel;

namespace Coffee_Application.DataController
{
    class Service : IService
    {
        /*
        private static Boolean IsSystemTest =
            ConfigurationManager.AppSettings["IsSystemTest"].Equals("true", StringComparison.CurrentCultureIgnoreCase);
        */

        private DataRepository repository;
        private static ExceptionMessage exceptionMessage = new ExceptionMessage();       
        private static List<LoginUser> currentLoginUsers = new List<LoginUser>();
        private static int loginActivityMinutesLimit = 30;

        public Service()
        {
            try
            {
                repository = new DataRepository();
            }
            catch (Exception e)
            {
                exceptionMessage.WriteException(e);
            }
        }

        public StoreType GetStoreData(string userId, string accountParentId, int activityId)
        {
            StoreType storeData = new StoreType();

            if (IsLoginUser(userId, activityId))  // only return data if user has logged in
            {
                storeData.StartPullDateTime = DateTime.Now;
                storeData.Message = "";
                //storeData.Stores = repository.GetStores(accountParentId);
                storeData.Success = storeData.Stores.Count > 0;
                storeData.FinishPullDateTime = DateTime.Now;
            }

            return storeData;
        }

        public StoreProductType GetStoreProductData(string userId, string accountProductId, int activityId)
        {
            StoreProductType storeProductData = new StoreProductType();

            if (IsLoginUser(userId, activityId))  // only return data if user has logged in
            {
                storeProductData.StartPullDateTime = DateTime.Now;
                storeProductData.Message = "";
                //storeProductData.StoreProducts = repository.GetStoreProducts(accountProductId);
                storeProductData.Success = storeProductData.StoreProducts.Count > 0;
                storeProductData.FinishPullDateTime = DateTime.Now;
            }

            return storeProductData;
        }

        public CustomerFavoriteProductType GetCustomerFavoriteProductData(string userId, string contactId, int activityId)
        {
            CustomerFavoriteProductType favoriteProductData = new CustomerFavoriteProductType();

            if (IsLoginUser(userId, activityId))  // only return data if user has logged in
            {
                favoriteProductData.StartPullDateTime = DateTime.Now;
                favoriteProductData.Message = "";
                //favoriteProductData.FavoriteProducts = repository.GetCustomerFavoriteProducts(contactId);
                //favoriteProductData.Success = favoriteProductData.FavoriteProducts.Count > 0;
                favoriteProductData.FinishPullDateTime = DateTime.Now;
            }

            return favoriteProductData;
        }

        public CustomerOrderType SetCustomerOrderData(string userId, List<CustomerOrder> customerOrder, int activityId)
        {
            CustomerOrderType customerOrderData = new CustomerOrderType();

            if (IsLoginUser(userId, activityId))  // only return data if user has logged in
            {
                customerOrderData.StartPullDateTime = DateTime.Now;
                customerOrderData.Message = "";
                //customerOrderData.CustomerOrders = repository.SetCustomerOrders(customerOrder);
                customerOrderData.Success = customerOrderData.CustomerOrders.Count > 0;
                customerOrderData.FinishPullDateTime = DateTime.Now;
            }

            return customerOrderData;

        }

        public LoginUserType GetLoginUser(string userName, string userPassword)
        {
            LoginUserType userData = new LoginUserType();

            userData.Message = "";

            if (!String.IsNullOrWhiteSpace(userName) && !String.IsNullOrWhiteSpace(userPassword))
            {
                //userData.User = repository.GetLoginUser(userName);

                /*
                if (userData.User != null)
                {
                    if (userData.User.Password__c == userPassword)
                    {
                        userData.Success = true;
                        userData.User.LoginDateTime = DateTime.Now;

                        // generate random number for login activity id, used for security purposes
                        userData.User.LoginActivityId = new Random().Next(10000, 1000000);

                        // add a user to login users list
                        if (!IsLoginUser(userData.User.Id))
                            currentLoginUsers.Add(userData.User);
                    }
                    else
                    {
                        userData.User.Id = null;
                        userData.User.Name = null;
                        userData.User.Username__c = null;
                        userData.User.MailingStreet = null;
                        userData.User.MailingCity = null;
                        userData.User.MailingState = null;
                        userData.User.MailingPostalCode = null;
                        userData.User.MailingCountry = null;
                        userData.User.Email = null;
                        userData.User.MobilePhone = null;
                    }

                    userData.User.Password__c = null; // hide password
                }
                 */
            }

            return userData;
        }

        private Boolean IsLoginUser(string userId)
        {
            Boolean userIsLogin = false;

            if (true)  //(IsSystemTest)
                userIsLogin = true;
            else
            {
                var loginUser = currentLoginUsers.Find(r => r.Id == userId);

                // remove user from the log
                if (loginUser != null)
                    currentLoginUsers.Remove(loginUser);
            }

            return userIsLogin;
        }

        private Boolean IsLoginUser(string userId, int activityId)
        {
            Boolean userIsLogin = false;

            if (true)  //(IsSystemTest)
                userIsLogin = true;
            else
            {
                var loginUser = currentLoginUsers.Find(r => r.Id == userId);
                if (loginUser != null)
                {
                    // remove user from the log
                    if (loginUser.LoginActivityId != activityId || DateTime.Now.Subtract(loginUser.LoginDateTime).TotalMinutes > loginActivityMinutesLimit)
                        currentLoginUsers.Remove(loginUser);
                    else
                        userIsLogin = true;
                }
            }

            return userIsLogin;
        }

    }
}