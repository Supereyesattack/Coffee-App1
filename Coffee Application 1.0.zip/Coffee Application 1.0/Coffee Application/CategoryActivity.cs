using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Newtonsoft.Json;
using Coffee_Application.DataModel;
using Salesforce.Common.Models;

namespace Coffee_Application
{
    [Activity(Label = "CategoryList")]
    public class CategoryActivity : Activity
    {
        public CustomListAdapter listAdapter;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            string json = Intent.GetStringExtra("CategoryData") ?? null;
            List<CustomList> items = new List<CustomList>();

            if (json != null)
            {
                // convert json string back to a list object
                var categoryList = JsonConvert.DeserializeObject<List<ProductCategory>>(json);

                for (int i = 0; i < categoryList.Count; i++)
                {
                    CustomList item = new CustomList();
                    item.Name = categoryList[i].Family__c;
                    item.Id = categoryList[i].Account__c;
                    //item.Image = Resource.Drawable.Icon;
                    items.Add(item);
                }
            }


            // Create your application here
            SetContentView(Resource.Layout.CategoryList);

            //Create our adapter
            listAdapter = new CustomListAdapter(this, items);

            //Find the listview reference
            var listView = FindViewById<ListView>(Resource.Id.CategoryListView);

            //Hook up our adapter to our ListView
            listView.Adapter = listAdapter;

            //Wire up the click event
            listView.ItemClick += async (sender, e) =>
            {
                //Get our item from the list adapter
                var item = this.listAdapter.GetItemAtPosition(e.Position);

                //Make a toast with the item name just to show it was clicked
                //Toast.MakeText(this, "Name: " +item.Name + " Id: " + item.Id + " Clicked!", ToastLength.Short).Show();

                // pass list object in the form of json string

                //
                var forceClient = Global.ForceClient;

                var soqlStoreString = string.Format("SELECT Id, Name, Description__c, Price__c, Account__c, Reward__c FROM Account_Product__c WHERE Account__c = '{0}' AND Family__c = '{1}'", item.Id, item.Name);

                List<StoreProduct> productList = new List<StoreProduct>();

                // Retrieve stores from Salesforce
                QueryResult<StoreProduct> results1 = await forceClient.QueryAsync<StoreProduct>(soqlStoreString);

                productList.AddRange(results1.records);

                var nextRecordsUrl = results1.nextRecordsUrl;

                if (!string.IsNullOrEmpty(nextRecordsUrl))
                {
                    while (true)
                    {
                        QueryResult<StoreProduct> continuationResults = await forceClient.QueryContinuationAsync<StoreProduct>(nextRecordsUrl);

                        productList.AddRange(continuationResults.records);

                        if (string.IsNullOrEmpty(continuationResults.nextRecordsUrl)) break;

                        //pass nextRecordsUrl back to client.QueryAsync to request next set of records                    
                        nextRecordsUrl = continuationResults.nextRecordsUrl;
                    }
                }

                string jsonStoreProduct = JsonConvert.SerializeObject(productList);

                Intent intent = new Intent(this, typeof(ProductActivity));
                intent.PutExtra("StoreProductData", jsonStoreProduct);
                StartActivity(intent);
            };

            /*void listView_ItemClick(object sender, AdapterView.ItemClickEventArgs e)
            {
                //Get our item from the list adapter
                var item = this.listAdapter.GetItemAtPosition(e.Position);

                //Make a toast with the item name just to show it was clicked
                Toast.MakeText(this, "Name: " + item.Name + " Id: " + item.Id + " Clicked!", ToastLength.Short).Show();
            }*/
        }
    }
}