﻿using System;

using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;

namespace login2
{
	[Activity (MainLauncher = true, Icon = "@drawable/icon")]
	public class MainActivity : Activity
	{

		protected override void OnCreate (Bundle bundle)
		{
			base.OnCreate (bundle);

			// Set our view from the "main" layout resource
			SetContentView (Resource.Layout.Main);

			Button SignIn = FindViewById<Button> (Resource.Id.btnSignIn);
			SignIn.Click += SignIn_Click;
		}
			
			void SignIn_Click(object sender, EventArgs e)
			{
				Intent intent = new Intent(this, typeof(VendorSelect));

				User user = new User () 
				{
					UserId = 123,
					Username = "Dlanyer"
					
				};

				intent.PutExtra ("UserID", user.UserId);
				intent.PutExtra ("Username", user.Username);
		
				this.StartActivity(intent);
				this.Finish();
			}
	}

	public class User
	{
		public int UserId;
		public string Username;

	}

	public class Location
	{
		public string VendorId;
		public string VendorName;

	}

	public class Product
	{
		public string ProductId;
		public string ProductName;

	}
}



