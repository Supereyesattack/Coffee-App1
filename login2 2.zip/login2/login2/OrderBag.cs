﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace login2
{
	[Activity (Label = "OrderBag")]			
	public class OrderBag : Activity
	{
		private Button ConfirmButton;
		private ListView YourOrdersListView;
		private List<String> YourOrdersList;
		private ArrayAdapter OrderListAdapter;

		protected override void OnCreate (Bundle bundle)
		{
			base.OnCreate (bundle);

			SetContentView (Resource.Layout.OrderBag);
			YourOrdersList = Intent.GetStringArrayListExtra ("ProductsOrdered").ToList();

			YourOrdersListView = FindViewById<ListView> (Resource.Id.YourOrdersListView);

			OrderListAdapter = new ArrayAdapter (this, Android.Resource.Layout.SimpleListItem1, YourOrdersList);
			YourOrdersListView.Adapter = OrderListAdapter;

			ConfirmButton = FindViewById<Button> (Resource.Id.ConfirmButton);
			ConfirmButton.Click += ConfirmButton_Click;




		}

		void ConfirmButton_Click (object sender, EventArgs e)
		{
			
			Intent intent = new Intent (this, typeof(OrderComplete));
			intent.PutStringArrayListExtra ("ProductsList", YourOrdersList);
			this.StartActivity (intent);
		}
	}
}

