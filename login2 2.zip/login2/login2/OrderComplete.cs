﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace login2
{
	[Activity (Label = "OrderComplete")]			
	public class OrderComplete : Activity
	{
		private List<String> CompletionList;

		protected override void OnCreate (Bundle bundle)
		{
			base.OnCreate (bundle);

			SetContentView (Resource.Layout.VendorSelect);

			CompletionList = Intent.GetStringArrayListExtra ("ProductsList").ToList();

		}
	}
}

