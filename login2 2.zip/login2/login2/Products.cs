﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace login2
{
	[Activity (Label = "Products")]			
	public class Products : Activity
	{
		private List<String> HotBeveragesItems;
		private ListView HotBeveragesListView;
		private ArrayAdapter HotBeveragesAdapter;
		private List<String> ProductsOrdered = new List<String>();
		private Button OrderButton;

		protected override void OnCreate (Bundle bundle)
		{
			base.OnCreate (bundle);

			SetContentView (Resource.Layout.HotBeverages);

			HotBeveragesListView = FindViewById<ListView>(Resource.Id.HotBeveragesListView);
			HotBeveragesItems = new List<String>();



			HotBeveragesItems.Add ("Item 1");
			HotBeveragesItems.Add ("Item 2");
			HotBeveragesItems.Add ("Item 3");

			HotBeveragesAdapter = new ArrayAdapter<String> (this, Android.Resource.Layout.SimpleListItem1, HotBeveragesItems);
			HotBeveragesListView.Adapter = HotBeveragesAdapter;

			HotBeveragesListView.ItemClick += HotBeveragesListView_ItemClick;

			OrderButton = FindViewById<Button> (Resource.Id.OrderButton);
			OrderButton.Click += OrderButton_Click;

		}

		void HotBeveragesListView_ItemClick (object sender, AdapterView.ItemClickEventArgs e)
		{
			ProductsOrdered.Add (HotBeveragesItems [e.Position]);
		}

		void OrderButton_Click (object sender, EventArgs e)
		{
			Intent intent = new Intent (this, typeof(OrderBag));
			intent.PutStringArrayListExtra ("ProductsOrdered", ProductsOrdered);
			this.StartActivity (intent);
		}

		//private void OrderButton_Clicked
	}
}

