﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace login2
{
	[Activity (Label = "LocationSelect")]			
	public class LocationSelect : Activity
	{

		private List<String> LocationItems;
		private ListView LocationListView;
		private ArrayAdapter LocationListAdaptor;

		protected override void OnCreate (Bundle bundle)
		{
			base.OnCreate (bundle);

			SetContentView (Resource.Layout.LocationSelect);

			LocationListView = FindViewById<ListView>(Resource.Id.LocationSelectListView);
			LocationItems = new List<String>();

			LocationItems.Add ("Location 1");

			LocationListAdaptor = new ArrayAdapter<String> (this, Android.Resource.Layout.SimpleListItem1, LocationItems);

			LocationListView.Adapter = LocationListAdaptor;
			LocationListView.ItemClick += Location1_Click;

			/*Button Location1;
			Button Location2;



			Location1 = FindViewById<Button> (Resource.Id.Location1);
			Location1.Click += Location1_Click;

			Location2 = FindViewById<Button> (Resource.Id.Location1);
			Location2.Click += Location1_Click;
			*/
		}

		void Location1_Click (object sender, EventArgs e)
		{
			Intent intent = new Intent(this, typeof(MainMenu));
			this.StartActivity(intent);
		}

	}
}

