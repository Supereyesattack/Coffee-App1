﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace login2
{
	[Activity (Label = "MainMenu")]			
	public class MainMenu : Activity
	{

		private List<String> ProductCategories;
		private ListView MainMenuListView;
		private ArrayAdapter MainMenuListAdaptor;

		protected override void OnCreate (Bundle bundle)
		{
			base.OnCreate (bundle);

			SetContentView (Resource.Layout.MainMenu);

			MainMenuListView = FindViewById<ListView>(Resource.Id.MainMenuListView);
			ProductCategories = new List<String>();

			ProductCategories.Add ("Hot Beverages");
			ProductCategories.Add ("Cold Beverages");
			ProductCategories.Add ("Dessert");

			MainMenuListAdaptor = new ArrayAdapter<String> (this, Android.Resource.Layout.SimpleListItem1, ProductCategories);

			MainMenuListView.Adapter = MainMenuListAdaptor;
			MainMenuListView.ItemClick += MainMenuListView_ItemClick;
		}

		void MainMenuListView_ItemClick (object sender, AdapterView.ItemClickEventArgs e)
		{
			Intent intent = new Intent(this, typeof(Products));
			intent.PutExtra("ProductCategory", ProductCategories [e.Position]);
			this.StartActivity(intent);
		}
	}
}

