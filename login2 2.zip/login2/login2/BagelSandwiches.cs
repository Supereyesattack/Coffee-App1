﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace login2
{
	[Activity (Label = "BagelSandwiches")]			
	public class BagelSandwiches : Activity
	{
		private List<String> mItems;
		private ListView mListView;

		protected override void OnCreate (Bundle bundle)
		{
			base.OnCreate (bundle);

			SetContentView (Resource.Layout.BagelSandwiches);

			mListView = FindViewById<ListView>(Resource.Id.BagelSandwichesListView);
			mItems = new List<String>();

			mItems.Add ("Vendor1");
			mItems.Add ("Vendor2");
			mItems.Add ("Vendor3");

		}
	}
}

