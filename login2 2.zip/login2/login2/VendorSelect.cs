﻿
using System;
using System.Collections.Generic;
//using System.Linq;
//using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace login2
{
	[Activity (Label = "VendorSelect")]			
	public class VendorSelect : Activity
	{
		//Button Vendor1;
		private List<String> mItems;
		private ListView mListView;
		//string[] items;
		ArrayAdapter ListAdapter;
		protected override void OnCreate (Bundle bundle)
		{
			string text;
			string text2;

			base.OnCreate (bundle);

			SetContentView (Resource.Layout.VendorSelect);

			mListView = FindViewById<ListView>(Resource.Id.ListViewVendorsID);
			mItems = new List<String>();

			//Iterate .add from database
			mItems.Add ("Vendor1");
			mItems.Add ("Vendor2");
			mItems.Add ("Vendor3");
			ListAdapter = new ArrayAdapter<String>(this, Android.Resource.Layout.SimpleListItem1, mItems);

			mListView.Adapter = ListAdapter;
			mListView.ItemClick += mListView_ItemClick;

			text = Intent.GetIntExtra ("UserID", 0).ToString ();
			text2 = Intent.GetStringExtra ("Username");

		}

		void mListView_ItemClick (object sender, AdapterView.ItemClickEventArgs e)
		{
			//string Activity = mItems [e.Position];
			Intent intent = new Intent(this, typeof(LocationSelect));
			//intent.PutExtra ("VendorID", mItems[e.Position]);

			List<Location> location = new List<Location> ();

			Location loc1 = new Location () 
			{
				VendorId = "1",
				VendorName = "V1"
			};

			Location loc2 = new Location () 
			{
				VendorId = "1",
				VendorName = "V1"
			};

			location.Add(loc1);
			location.Add(loc2);

				
			this.StartActivity(intent);
		}
	}
}

