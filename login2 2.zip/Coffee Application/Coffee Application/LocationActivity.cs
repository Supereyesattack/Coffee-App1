using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Newtonsoft.Json;
using Coffee_Application.DataModel;
using Salesforce.Common.Models;

namespace Coffee_Application
{
    [Activity(Label = "LocationList")]
    public class LocationActivity : Activity
    {
        public CustomListAdapter listAdapter;

        protected override void OnCreate(Bundle bundle)
        {        
            base.OnCreate(bundle);

            string json = Intent.GetStringExtra("LocationData") ?? null;
            List<CustomList> items = new List<CustomList>();

            if (json != null)
            {
                // convert json string back to a list object
                var storeList = JsonConvert.DeserializeObject<List<Store>>(json);
                
                for (int i = 0; i < storeList.Count; i++)
                {
                    CustomList item = new CustomList();
                    item.Name = storeList[i].Name;
                    item.Id = storeList[i].ParentId;
                    //item.Image = Resource.Drawable.Icon;
                    items.Add(item);
                }
            }

            
            // Create your application here
            SetContentView(Resource.Layout.LocationList);

            //Create our adapter
            listAdapter = new CustomListAdapter(this, items);

            //Find the listview reference
            var listView = FindViewById<ListView>(Resource.Id.LocationListView);

            //Hook up our adapter to our ListView
            listView.Adapter = listAdapter;

            //Wire up the click event
            listView.ItemClick += async (sender, e) =>
            {
                //Get our item from the list adapter
                var item = this.listAdapter.GetItemAtPosition(e.Position);

                //Make a toast with the item name just to show it was clicked
                //Toast.MakeText(this, "Name: " +item.Name + " Id: " + item.Id + " Clicked!", ToastLength.Short).Show();

                // pass list object in the form of json string

                //
                var forceClient = Global.ForceClient;

                var soqlStoreString = string.Format("SELECT Account__c, Family__c FROM Account_Product__c WHERE Account__c = '{0}' AND Family__c != '' GROUP BY Account__c, Family__c", item.Id);

                List<ProductCategory> categoryList = new List<ProductCategory>();

                // Retrieve stores from Salesforce
                QueryResult<ProductCategory> results1 = await forceClient.QueryAsync<ProductCategory>(soqlStoreString);

                categoryList.AddRange(results1.records);

                var nextRecordsUrl = results1.nextRecordsUrl;

                if (!string.IsNullOrEmpty(nextRecordsUrl))
                {
                    while (true)
                    {
                        QueryResult<ProductCategory> continuationResults = await forceClient.QueryContinuationAsync<ProductCategory>(nextRecordsUrl);

                        categoryList.AddRange(continuationResults.records);

                        if (string.IsNullOrEmpty(continuationResults.nextRecordsUrl)) break;

                        //pass nextRecordsUrl back to client.QueryAsync to request next set of records                    
                        nextRecordsUrl = continuationResults.nextRecordsUrl;
                    }
                }
                //

                string jsonCategory = JsonConvert.SerializeObject(categoryList);

                Intent intent = new Intent(this, typeof(CategoryActivity));
                intent.PutExtra("CategoryData", jsonCategory);
                StartActivity(intent);
            };


        }
    }
}