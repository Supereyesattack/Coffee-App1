﻿using System;
using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;

using Coffee_Application.DataModel;
using Coffee_Application.DataController;
using System.Collections.Generic;
using System.Threading.Tasks;

using System.Net.Http;
using Newtonsoft.Json;
using Salesforce.Force;
using Salesforce.Common;
using Salesforce.Common.Models;

//using Salesforce;

namespace Coffee_Application
{
    [Activity(Label = "Coffee_Application", MainLauncher = true, Icon = "@drawable/icon")]
    public class MainActivity : Activity
    {
        private static string consumerKey = "3MVG9fMtCkV6eLhfrqYgIEUifLDXx6ztdUXjsHXkVDL81lmI7ZYlmmPG0We1mJYBQlq5yl3_doyZKXWgoVpVs";
        private static string consumerSecret = "8718126830326927672";
        private static string url = "https://login.salesforce.com/services/oauth2/token";
        private static AuthenticationClient authClient = new AuthenticationClient();
        private int count = 1;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.Main);

            
            // Get our button from the layout resource,
            // and attach an event to it
            Button button = FindViewById<Button>(Resource.Id.MyButton);

            button.Click += delegate 
                { 
                    button.Text = string.Format("{0} clicks!", count++); 

                };

            Button download = FindViewById<Button>(Resource.Id.XamarinButton);
            download.Click += async (sender, e) =>
            {
                Task<int> sizeTask = DownloadHomepage();

                FindViewById<TextView>(Resource.Id.ResultTextView).Text = "loading...";
                FindViewById<TextView>(Resource.Id.ResultEditText).Text = "loading...";

                // await! control returns to the caller
                var intResult = await sizeTask;

                // when the Task<int> returns, the value is available and we can display on the UI
                FindViewById<TextView>(Resource.Id.ResultTextView).Text = "Length: " + intResult;
                // "returns" void, since it's an event handler
            };

            Button authenticate = FindViewById<Button>(Resource.Id.AuthenticateButton);
            authenticate.Click += async (sender, e) =>
            {
                string username = "docampo@shaw.ca";
                string password = "dlanyert2z0n6";

                FindViewById<TextView>(Resource.Id.UsernameEditText).Text = username;
                FindViewById<TextView>(Resource.Id.PasswordEditText).Text = password;

                //string username = FindViewById<TextView>(Resource.Id.UsernameEditText).Text;
                //string password = FindViewById<TextView>(Resource.Id.PasswordEditText).Text;

                Task<bool> clientTask = AuthenticateClient(username, password);

                FindViewById<TextView>(Resource.Id.ResultTextView).Text = "authenticating...";
                FindViewById<TextView>(Resource.Id.ResultEditText).Text = "authenticating...";

                // await! control returns to the caller
                bool clientIsAuthenticated = await clientTask;

                // when the Task<ForceClient> returns, the value is available and we can display on the UI
                FindViewById<TextView>(Resource.Id.ResultTextView).Text = "Authenticated: " + clientIsAuthenticated;

                if (clientIsAuthenticated && authClient.Id != null)
                {

                    //ForceClient forceClient = new ForceClient(authClient.InstanceUrl, authClient.AccessToken, authClient.ApiVersion, new HttpClient());
                    ForceClient forceClient = new ForceClient(authClient.InstanceUrl, authClient.AccessToken, authClient.ApiVersion);

                    var soqlLoginString = string.Format("SELECT Id, Name, Username, Total_Rewards__c, Street, City, State, PostalCode, Country, Email, Phone FROM User WHERE Username = '{0}'", username);
                    List<LoginUser> loginUserList = new List<LoginUser>();

                    try
                    {
                        // Retrieve the login user info from Salesforce
                        QueryResult<LoginUser> results = await forceClient.QueryAsync<LoginUser>(soqlLoginString);

                        FindViewById<TextView>(Resource.Id.ResultEditText).Text += "Client is querying records...";

                        loginUserList.AddRange(results.records);

                        var nextRecordsUrl = results.nextRecordsUrl;

                        if (!string.IsNullOrEmpty(nextRecordsUrl))
                        {
                            while (true)
                            {
                                QueryResult<LoginUser> continuationResults = await forceClient.QueryContinuationAsync<LoginUser>(nextRecordsUrl);

                                FindViewById<TextView>(Resource.Id.ResultEditText).Text += "Client is querying more records...";

                                loginUserList.AddRange(continuationResults.records);

                                if (string.IsNullOrEmpty(continuationResults.nextRecordsUrl)) break;

                                //pass nextRecordsUrl back to client.QueryAsync to request next set of records                    
                                nextRecordsUrl = continuationResults.nextRecordsUrl;
                            }
                        }
                    }
                    catch (Exception exception)
                    {
                        FindViewById<TextView>(Resource.Id.ResultEditText).Text = "Client error..." + exception.ToString();
                    }

                    if (loginUserList.Count > 0)
                    {

                        var soqlStoreString = string.Format("SELECT Id, Name, ParentId FROM Account WHERE ParentId = '' AND Industry = 'Food & Beverage'");

                        List<Store> storeList = new List<Store>();

                        // Retrieve stores from Salesforce
                        QueryResult<Store> results1 = await forceClient.QueryAsync<Store>(soqlStoreString);

                        storeList.AddRange(results1.records);

                        var nextRecordsUrl = results1.nextRecordsUrl;

                        if (!string.IsNullOrEmpty(nextRecordsUrl))
                        {
                            while (true)
                            {
                                QueryResult<Store> continuationResults = await forceClient.QueryContinuationAsync<Store>(nextRecordsUrl);

                                storeList.AddRange(continuationResults.records);

                                if (string.IsNullOrEmpty(continuationResults.nextRecordsUrl)) break;

                                //pass nextRecordsUrl back to client.QueryAsync to request next set of records                    
                                nextRecordsUrl = continuationResults.nextRecordsUrl;
                            }
                        }

                        if (storeList.Count > 0)
                        {
                            Global.Name = loginUserList[0].Name;
                            Global.ForceClient = forceClient;

                            // pass list object in the form of json string
                            string json = JsonConvert.SerializeObject(storeList);

                            Intent intent = new Intent(this, typeof(VendorActivity));
                            intent.PutExtra("VendorData", json);
                            StartActivity(intent);
                        }
                    }
                }

                // "returns" void, since it's an event handler
            };
        }

        public async Task<int> DownloadHomepage()
        {
            var httpClient = new HttpClient(); // Xamarin supports HttpClient!

            Task<string> contentsTask = httpClient.GetStringAsync("http://xamarin.com"); // async method!

            // await! control returns to the caller and the task continues to run on another thread
            string contents = await contentsTask;

            TextView resultEditText = FindViewById<TextView>(Resource.Id.ResultEditText);
            resultEditText.Text += "DownloadHomepage method continues after async call. . . . .\n";

            // After contentTask completes, you can calculate the length of the string.
            int exampleInt = contents.Length;

            resultEditText.Text += "Downloaded the html and found out the length.\n\n\n";

            resultEditText.Text += contents; // just dump the entire HTML

            return exampleInt; // Task<TResult> returns an object of type TResult, in this case int
        }

        public async Task<bool> AuthenticateClient(string username, string password)
        {
            TextView resultEditText = FindViewById<TextView>(Resource.Id.ResultEditText);

            //create auth client to retrieve token
            var authTask = authClient.UsernamePasswordAsync(consumerKey, consumerSecret, username, password, url);
            try
            {
                await authTask;

                resultEditText.Text += "AuthenticateClient method continues after async call. . . . .\n";
                resultEditText.Text += "Authenticated the Salesforce client.\n\n\n";

                return true;
            }
            catch (Exception e)
            {
                resultEditText.Text += "AuthenticateClient method error. . . . .\n" + e.ToString();

                return false;
            }            
        }

    }

    public static class Global
    {
        public static string Name { get; set; }
        public static ForceClient ForceClient { get; set; }
    }
}
