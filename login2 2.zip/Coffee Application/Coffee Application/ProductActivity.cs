using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Newtonsoft.Json;
using Coffee_Application.DataModel;

namespace Coffee_Application
{
    [Activity(Label = "ProductList")]
    public class ProductActivity : Activity
    {
        public CustomProductListAdapter listAdapter;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            string json = Intent.GetStringExtra("StoreProductData") ?? null;
            List<CustomProductList> items = new List<CustomProductList>();

            if (json != null)
            {
                // convert json string back to a list object
                var productList = JsonConvert.DeserializeObject<List<StoreProduct>>(json);

                for (int i = 0; i < productList.Count; i++)
                {
                    CustomProductList item = new CustomProductList();
                    item.Name = productList[i].Name;
                    item.Price = productList[i].Price__c;
                    item.Id = productList[i].Id;
                    //item.Image = Resource.Drawable.Icon;
                    items.Add(item);
                }
            }


            // Create your application here
            SetContentView(Resource.Layout.ProductList);

            //Create our adapter
            listAdapter = new CustomProductListAdapter(this, items);

            //Find the listview reference
            var listView = FindViewById<ListView>(Resource.Id.ProductListView);

            //Hook up our adapter to our ListView
            listView.Adapter = listAdapter;

            //Wire up the click event
            listView.ItemClick += listView_ItemClick;

        }

        void listView_ItemClick(object sender, AdapterView.ItemClickEventArgs e)
        {
            //Get our item from the list adapter
            var item = this.listAdapter.GetItemAtPosition(e.Position);

            //Make a toast with the item name just to show it was clicked
            Toast.MakeText(this, "Name: " + item.Name + " Id: " + item.Id + " Clicked!", ToastLength.Short).Show();
        }
    }
}