using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Dynamic;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

using Newtonsoft.Json;
using Coffee_Application.DataModel;
using Salesforce.Common.Models;
using System.Threading.Tasks;
using Salesforce.Force;

namespace Coffee_Application
{
    [Activity(Label = "@string/ApplicationName")]
    public class OrderBagActivity : Activity
    {
        public CustomOrderBagListAdapter listAdapter;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            string accountId = Intent.GetStringExtra("AccountId") ?? null;
            string json = Intent.GetStringExtra("OrderBagData") ?? null;

            // List of order items ready to process, used for display
            List<CustomerOrderItem> items = new List<CustomerOrderItem>();

            // List of order items for submitted for processing, elements originally copied from "List<CustomerOrderItem> items"
            // Every item processed will be deleted from this list, and the remaining can be re-submitted for processing
            List<CustomerOrderItem> items2Process = new List<CustomerOrderItem>();

            if (json != null)
            {
                // convert json string back to a list object
                var orderList = JsonConvert.DeserializeObject<List<CustomerOrderItem>>(json);

                for (int i = 0; i < orderList.Count; i++)
                {
                    CustomerOrderItem item = new CustomerOrderItem();
                    item.Account_Product__c = orderList[i].Account_Product__c;
                    item.Product_Name__c = orderList[i].Product_Name__c;
                    item.Unit_Price__c = orderList[i].Unit_Price__c;
                    item.Quantity__c = orderList[i].Quantity__c;
                    item.Reward__c = orderList[i].Reward__c;
                    items.Add(item);
                }

                // copy the items to another list for processing
                items2Process.AddRange(items);
            }

            // Create your application here
            SetContentView(Resource.Layout.OrderBagList);

            //Create our adapter
            listAdapter = new CustomOrderBagListAdapter(this, items);

            //Find the listview reference
            var listView = FindViewById<ListView>(Resource.Id.OrderBagListView);

            //Hook up our adapter to our ListView
            listView.Adapter = listAdapter;

            // Get our button from the layout resource,
            // and attach an event to it
            Button viewConfirmButton = FindViewById<Button>(Resource.Id.OrderBagConfirmButton);

            // enable or disable the submit button
            viewConfirmButton.Enabled = accountId != null && items2Process.Count > 0;
            viewConfirmButton.Clickable = accountId != null && items2Process.Count > 0;

            viewConfirmButton.Click += async (sender, e) =>
            {
                // disable the button so user cannot click it during the submission process
                viewConfirmButton.Enabled = false;
                viewConfirmButton.Clickable = false;

                TextView resultText = FindViewById<TextView>(Resource.Id.OrderBagTextView);

                int orderItemCount = items2Process.Count;

                if (accountId != null && orderItemCount > 0)
                {
                    var forceClient = Global.ForceClient;
                    string customerOrderId = "";

                    try
                    {
                        dynamic customerOrder = new ExpandoObject();
                        customerOrder.Customer__c = Global.UserId;
                        customerOrder.Account__c = accountId;
                        
                        customerOrderId = await forceClient.CreateAsync("Customer_Order__c", customerOrder);

                        resultText.Text += "Submitting the order...\n";

                        if (customerOrderId != null)
                        {
                            int remove = 0;

                            for (int i = 0; i < orderItemCount; i++)
                            {
                                dynamic orderItem = new ExpandoObject();

                                orderItem.CustomerOrderId__c = customerOrderId;
                                orderItem.Account_Product__c = items2Process[i].Account_Product__c;
                                orderItem.Unit_Price__c = items2Process[i].Unit_Price__c;
                                orderItem.Quantity__c = items2Process[i].Quantity__c;
                                orderItem.Reward__c = items2Process[i].Reward__c;

                                var orderItemId = await forceClient.CreateAsync("Customer_Order_Item__c", orderItem);
                                resultText.Text += "Creating the order item " + items2Process[i].Product_Name__c + "...\n";

                                if (orderItemId == null)
                                {
                                    resultText.Text += "Failed to process the order item " + items2Process[i].Product_Name__c + "...\n";
                                    break;
                                }
                                else
                                {
                                    remove++;
                                    resultText.Text = "Processed the order item " + items2Process[i].Product_Name__c + ".\n";
                                }
                            }

                            // remove successfully processed records
                            if (remove > 0)
                                items2Process.RemoveRange(0, remove);
                        }
                        else
                            resultText.Text += "Failed to submit the order! Please try again.\n";
                    }
                    catch (Exception exception)
                    {
                        resultText.Text = "Failed to submit the order because of the following critical error: " + exception.Message + "\n";
                    }

                    // disable submit button if all records have been successfully submitted
                    if (items2Process.Count > 0)
                        resultText.Text = "Failed to process " + items2Process.Count.ToString() + " item(s)! Please try to submit again.\n";
                    else
                    {
                        resultText.Text = "Successfully submitted the order. Thank you...";

                        // Get the newly created order for the receipt number
                        var soqlStoreString = string.Format("SELECT Name, Total_Amount__c FROM Customer_Order__c WHERE Id = '{0}' LIMIT 1", customerOrderId);

                        // Retrieve stores from Salesforce
                        QueryResult<CustomerOrder> results = await forceClient.QueryAsync<CustomerOrder>(soqlStoreString);

                        if (results.records.Count > 0)
                        {
                            Intent intent = new Intent(this, typeof(OrderBagReceiptActivity));
                            intent.PutExtra("ReceiptNumber", results.records[0].Name);
                            StartActivity(intent);

                            /*
                            var alert = new AlertDialog.Builder(this);
                            alert.SetView(LayoutInflater.Inflate(Resource.Layout.OrderBagReceipt, null));
                            alert.Create().Show();
                            */

                            /*
                            //set alert for executing the task
                            AlertDialog.Builder alert = new AlertDialog.Builder(this);

                            alert.SetTitle("Please present this number: " + results.records[0].Name);

                            alert.SetPositiveButton("OK", (senderAlert, args) =>
                            {
                                Intent intent = new Intent(this, typeof(MenuSelectionActivity));
                                StartActivity(intent);
                            });

                            //run the alert in UI thread to display in the screen
                            RunOnUiThread(() =>
                            {
                                alert.Show();
                            });
                             */
                        }
                    }
                }
                else
                    resultText.Text = "Your order bag is empty!";

                // enable or disable the submit button
                viewConfirmButton.Enabled = accountId != null && items2Process.Count > 0;
                viewConfirmButton.Clickable = accountId != null && items2Process.Count > 0;
            };
        }
    }
}