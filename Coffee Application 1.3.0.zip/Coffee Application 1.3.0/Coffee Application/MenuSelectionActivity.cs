using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Coffee_Application.DataModel;
using Salesforce.Common.Models;
using Newtonsoft.Json;

namespace Coffee_Application
{
    [Activity(Label = "@string/ApplicationName")]
    public class MenuSelectionActivity : Activity
    {
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            SetContentView(Resource.Layout.MenuSelection);

            var forceClient = Global.ForceClient;

            Button selectOrder = FindViewById<Button>(Resource.Id.MenuSelectionOrderImageButton);
            selectOrder.Click += async (sender, e) =>
            {
                var soqlStoreString = string.Format("SELECT Id, Name, ParentId FROM Account WHERE ParentId != '' AND Industry = 'Food & Beverage' Order By Name");

                List<Store> storeList = new List<Store>();

                // Retrieve stores from Salesforce
                QueryResult<Store> results = await forceClient.QueryAsync<Store>(soqlStoreString);

                storeList.AddRange(results.records);

                var nextRecordsUrl = results.nextRecordsUrl;

                if (!string.IsNullOrEmpty(nextRecordsUrl))
                {
                    while (true)
                    {
                        QueryResult<Store> continuationResults = await forceClient.QueryContinuationAsync<Store>(nextRecordsUrl);

                        storeList.AddRange(continuationResults.records);

                        if (string.IsNullOrEmpty(continuationResults.nextRecordsUrl)) break;

                        //pass nextRecordsUrl back to client.QueryAsync to request next set of records                    
                        nextRecordsUrl = continuationResults.nextRecordsUrl;
                    }
                }

                if (storeList.Count > 0)
                {
                    // pass list object in the form of json string
                    string jsonLocation = JsonConvert.SerializeObject(storeList);

                    Intent intent = new Intent(this, typeof(LocationActivity));
                    intent.PutExtra("LocationData", jsonLocation);
                    StartActivity(intent);
                }
            };
        }
    }
}