using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace Coffee_Application.DataModel
{
    public class CustomOrderBagListAdapter : BaseAdapter
    {
        Activity context;

        public List<CustomerOrderItem> items = new List<CustomerOrderItem>();

        public CustomOrderBagListAdapter(Activity context, List<CustomerOrderItem> data) //We need a context to inflate our row view from
            : base()
        {
            this.context = context;

            for (int i = 0; i < data.Count; i++)
            {
                CustomerOrderItem item = new CustomerOrderItem();
                item.Account_Product__c = data[i].Account_Product__c;
                item.Product_Name__c = data[i].Product_Name__c;
                item.Unit_Price__c = data[i].Unit_Price__c;
                item.Quantity__c = data[i].Quantity__c;
                item.Reward__c = data[i].Reward__c;
                items.Add(item);
            }
        }

        public override int Count
        {
            get { return items.Count; }
        }

        public override Java.Lang.Object GetItem(int position)
        {
            return position;
        }

        public override long GetItemId(int position)
        {
            return position;
        }

        public override View GetView(int position, View convertView, ViewGroup parent)
        {
            //Get our object for this position
            var item = items[position];

            //Try to reuse convertView if it's not  null, otherwise inflate it from our item layout
            // This gives us some performance gains by not always inflating a new view
            // This will sound familiar to MonoTouch developers with UITableViewCell.DequeueReusableCell()
            var view = (convertView ??
                context.LayoutInflater.Inflate(
                    Resource.Layout.CustomOrderBagListItem,
                    parent,
                    false)) as LinearLayout;

            //Find references to each subview in the list item's view
            var textProduct = view.FindViewById(Resource.Id.ProductTextView) as TextView;
            var textPrice = view.FindViewById(Resource.Id.PriceTextView) as TextView;
            var textQuantity = view.FindViewById(Resource.Id.QuantityTextView) as TextView;
            var textTotalAmount = view.FindViewById(Resource.Id.TotalAmountTextView) as TextView;

            //Assign this item's values to the various subviews
            textProduct.SetText(item.Product_Name__c, TextView.BufferType.Normal);
            textPrice.SetText(item.Unit_Price__c.ToString(), TextView.BufferType.Normal);
            textQuantity.SetText(item.Quantity__c.ToString(), TextView.BufferType.Normal);
            textTotalAmount.SetText((item.Quantity__c * item.Unit_Price__c).ToString(), TextView.BufferType.Normal);

            //Finally return the view
            return view;
        }

        public CustomerOrderItem GetItemAtPosition(int position)
        {
            return items[position];
        }

      
    }
}