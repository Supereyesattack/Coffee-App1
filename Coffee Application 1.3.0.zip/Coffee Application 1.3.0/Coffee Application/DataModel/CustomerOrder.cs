using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace Coffee_Application.DataModel
{
    public class CustomerOrder
    {
        public const String SObjectTypeName = "Customer_Order__c";
        public String Id { get; set;  }
        public String Name { get; set; }
        public String Account__c { get; set; }
        public String Customer__c { get; set; }
        public Decimal Total_Amount__c { get; set; }
    }
}