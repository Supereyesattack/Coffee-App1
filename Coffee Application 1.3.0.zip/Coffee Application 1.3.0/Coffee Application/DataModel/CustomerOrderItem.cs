using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace Coffee_Application.DataModel
{
    public class CustomerOrderItem
    {
        public const String SObjectTypeName = "Customer_Order_Item__c";
        public String Id { get; set; }
        public String CustomerOrderId__c { get; set; }
        public String Account_Product__c { get; set; }
        public String Product_Name__c { get; set; }
        public Decimal Quantity__c { get; set; }
        public Decimal Unit_Price__c { get; set; }
        public Decimal Reward__c { get; set; }
    }
}