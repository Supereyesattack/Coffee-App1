﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Coffee_Application.Conroller;

using System.Threading.Tasks;
using System.Net.Http;

using Newtonsoft.Json;

// Force.com Toolkit for .NET https://github.com/developerforce/Force.com-Toolkit-for-NET
using Salesforce.Force;
using Salesforce.Common;
using Salesforce.Common.Models;

namespace CoffeeApplicationUnitTests
{

    [TestClass]
    public class CoffeeAppUnitTest
    {

        [TestMethod]
        public void TestMethod1()
        {

            Task.Run(async () =>
            {

                ApplicationService target = new ApplicationService();

                string username = "docampo@shaw.ca";
                string password = "dlanyert2z0n6";

                var actual = target.GetLoginUser(username, password);

                await actual;
                Assert.IsNotNull(actual);

            }).GetAwaiter().GetResult();
        }
    }
}
