using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Coffee_Application.DataModel;

namespace Coffee_Application.DataController
{
    public interface IService
    {
        StoreType GetStoreData(string userId, string accountParentId, int activityId);

        StoreProductType GetStoreProductData(string userId, string accountProductId, int activityId);

        CustomerFavoriteProductType GetCustomerFavoriteProductData(string userId, string contactId, int activityId);

        LoginUserType GetLoginUser(string userName, string userPassword);

        CustomerOrderType SetCustomerOrderData(string userId, List<CustomerOrder> customerOrder, int activityId);
    }

    public class LoginUserType : RecordType
    {
        LoginUser user = new LoginUser();

        public LoginUser User
        {
            get { return user; }
            set { user = value; }
        }
    }

    public class CustomerOrderType : RecordType
    {
        List<CustomerOrder> customerOrders = new List<CustomerOrder>();

        public List<CustomerOrder> CustomerOrders
        {
            get { return customerOrders; }
            set { customerOrders = value; }
        }
    }

    public class StoreProductType : RecordType
    {
        List<StoreProduct> storeProducts = new List<StoreProduct>();

        public List<StoreProduct> StoreProducts
        {
            get { return storeProducts; }
            set { storeProducts = value; }
        }
    }

    public class CustomerFavoriteProductType : RecordType
    {
        List<CustomerFavoriteProduct> customerFavoriteProducts = new List<CustomerFavoriteProduct>();

        public List<CustomerFavoriteProduct> CustomerFavoriteProducts
        {
            get { return customerFavoriteProducts; }
            set { customerFavoriteProducts = value; }
        }
    }

    public class StoreType : RecordType
    {
        List<Store> stores = new List<Store>();

        public List<Store> Stores
        {
            get { return stores; }
            set { stores = value; }
        }
    }

    public class RecordType
    {
        DateTime startPullDateTime = DateTime.Now;
        DateTime finishPullDateTime = DateTime.Now;
        String message = "Unable to retrieve records.";
        Boolean success = false;

        public DateTime StartPullDateTime
        {
            get { return startPullDateTime; }
            set { startPullDateTime = value; }
        }

        public DateTime FinishPullDateTime
        {
            get { return finishPullDateTime; }
            set { finishPullDateTime = value; }
        }

        public String Message
        {
            get { return message; }
            set { message = value; }
        }

        public Boolean Success
        {
            get { return success; }
            set { success = value; }
        }
    }
}