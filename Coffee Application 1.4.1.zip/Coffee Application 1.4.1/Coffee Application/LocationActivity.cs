/* Screen     : Location Selection
*  Description: This will query the stores and product categories from Salesforce and display stores on screen for selection
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Newtonsoft.Json;
using Coffee_Application.DataModel;
using Salesforce.Common.Models;
using System.Threading.Tasks;

namespace Coffee_Application
{
    [Activity(Label = "@string/ApplicationName")]
    public class LocationActivity : Activity
    {
        public CustomListAdapter listAdapter;

        protected override void OnCreate(Bundle bundle)
        {        
            base.OnCreate(bundle);

            string json = Intent.GetStringExtra("LocationData") ?? null;
            List<CustomList> items = new List<CustomList>();

            if (json != null)
            {
                // convert json string back to a list object
                var storeList = JsonConvert.DeserializeObject<List<Store>>(json);
                
                for (int i = 0; i < storeList.Count; i++)
                {
                    CustomList item = new CustomList();
                    item.Name = storeList[i].Name;
                    item.Id = storeList[i].Id;
                    item.ParentId = storeList[i].ParentId;
                    items.Add(item);
                }
            }
            
            // Create your application here
            SetContentView(Resource.Layout.LocationList);

            //Create our adapter
            listAdapter = new CustomListAdapter(this, items);

            //Find the listview reference
            var listView = FindViewById<ListView>(Resource.Id.LocationListView);

            //Hook up our adapter to our ListView
            listView.Adapter = listAdapter;

            //Wire up the click event
            listView.ItemClick += async (sender, e) =>
            {
                //Get our item from the list adapter
                var item = this.listAdapter.GetItemAtPosition(e.Position);

                Task<string> categoryTask = GetCategoryList(item.ParentId);

                string jsonCategory = await categoryTask;
                   
                Intent intent = new Intent(this, typeof(CategoryActivity));
                intent.PutExtra("AccountId", item.Id);
                intent.PutExtra("AccountParentId", item.ParentId);
                intent.PutExtra("CategoryData", jsonCategory);
                StartActivity(intent);
            };


        }

        // This is the method that queries the product categories from Salesforce
        public async Task<string> GetCategoryList(string itemParentId)
        {
            var forceClient = Global.ForceClient;

            var soqlStoreString = string.Format("SELECT Account__c, Family__c FROM Account_Product__c WHERE Account__c = '{0}' AND Family__c != '' GROUP BY Account__c, Family__c", itemParentId);

            List<ProductCategory> categoryList = new List<ProductCategory>();

            // Retrieve stores from Salesforce
            QueryResult<ProductCategory> results = await forceClient.QueryAsync<ProductCategory>(soqlStoreString);

            categoryList.AddRange(results.records);

            var nextRecordsUrl = results.nextRecordsUrl;

            if (!string.IsNullOrEmpty(nextRecordsUrl))
            {
                while (true)
                {
                    QueryResult<ProductCategory> continuationResults = await forceClient.QueryContinuationAsync<ProductCategory>(nextRecordsUrl);

                    categoryList.AddRange(continuationResults.records);

                    if (string.IsNullOrEmpty(continuationResults.nextRecordsUrl)) break;

                    //pass nextRecordsUrl back to client.QueryAsync to request next set of records                    
                    nextRecordsUrl = continuationResults.nextRecordsUrl;
                }
            }
            //

            return JsonConvert.SerializeObject(categoryList);

        }
    }
}