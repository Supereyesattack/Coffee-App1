/* Screen     : Confirmation Receipt
*  Description: Shows confirmation of orders with the receipt number
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Dynamic;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

using Newtonsoft.Json;
using Coffee_Application.DataModel;
using Salesforce.Common.Models;
using System.Threading.Tasks;
using Salesforce.Force;

namespace Coffee_Application
{
    [Activity(Label = "@string/ApplicationName")]
    public class OrderBagReceiptActivity : Activity
    {
        public CustomOrderBagListAdapter listAdapter;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            string receiptNumber = Intent.GetStringExtra("ReceiptNumber") ?? null;

            // Create your application here
            SetContentView(Resource.Layout.OrderBagReceipt);

            FindViewById<TextView>(Resource.Id.ReceiptNumberTextView).Text = receiptNumber;

            // Get our button from the layout resource,
            // and attach an event to it
            Button viewOKButton = FindViewById<Button>(Resource.Id.ModalOKButton);
            viewOKButton.Click += viewOKButton_Click;            
        }

        void viewOKButton_Click(object sender, EventArgs e)
        {
            Intent intent = new Intent(this, typeof(MenuSelectionActivity));
            StartActivity(intent);
        }
    }
}