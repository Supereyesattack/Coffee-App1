/* Screen     : Menu Selection
*  Description: Button selection of Order Entry, Top 5 Favorites and Profile
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Coffee_Application.DataModel;
using Salesforce.Common.Models;
using Newtonsoft.Json;

namespace Coffee_Application
{
    [Activity(Label = "@string/ApplicationName")]
    public class MenuSelectionActivity : Activity
    {
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            SetContentView(Resource.Layout.MenuSelection);

            var forceClient = Global.ForceClient;

            Button selectOrder = FindViewById<Button>(Resource.Id.MenuSelectionOrderImageButton);
            selectOrder.Click += async (sender, e) =>
            {
                var soqlStoreString = string.Format("SELECT Id, Name, ParentId FROM Account WHERE ParentId != '' AND Industry = 'Food & Beverage' Order By Name");

                List<Store> storeList = new List<Store>();

                // Retrieve stores from Salesforce
                QueryResult<Store> results = await forceClient.QueryAsync<Store>(soqlStoreString);

                storeList.AddRange(results.records);

                var nextRecordsUrl = results.nextRecordsUrl;

                if (!string.IsNullOrEmpty(nextRecordsUrl))
                {
                    while (true)
                    {
                        QueryResult<Store> continuationResults = await forceClient.QueryContinuationAsync<Store>(nextRecordsUrl);

                        storeList.AddRange(continuationResults.records);

                        if (string.IsNullOrEmpty(continuationResults.nextRecordsUrl)) break;

                        //pass nextRecordsUrl back to client.QueryAsync to request next set of records                    
                        nextRecordsUrl = continuationResults.nextRecordsUrl;
                    }
                }

                if (storeList.Count > 0)
                {
                    // pass list object in the form of json string
                    string jsonLocation = JsonConvert.SerializeObject(storeList);

                    Intent intent = new Intent(this, typeof(LocationActivity));
                    intent.PutExtra("LocationData", jsonLocation);
                    StartActivity(intent);
                }
            };

            Button topFavorite = FindViewById<Button>(Resource.Id.MenuSelectionFavoriteImageButton);
            selectOrder.Click += async (sender, e) =>
            {
                // Query top 5 most ordered products
                var soqlStoreString = string.Format("SELECT Account_Product__c, Account_Product__r.Name Name, SUM(Quantity__c) Quantity__c FROM Customer_Order_Item__c WHERE CustomerOrderId__r.Customer__c = {0} GROUP BY Account_Product__c, Account_Product__r.Name ORDER BY SUM(Quantity__c) DESC LIMIT 5", Global.UserId);

                List<CustomerFavoriteProduct> favoriteList = new List<CustomerFavoriteProduct>();

                // Retrieve stores from Salesforce
                QueryResult<CustomerFavoriteProduct> results = await forceClient.QueryAsync<CustomerFavoriteProduct>(soqlStoreString);

                favoriteList.AddRange(results.records);

                var nextRecordsUrl = results.nextRecordsUrl;

                if (!string.IsNullOrEmpty(nextRecordsUrl))
                {
                    while (true)
                    {
                        QueryResult<CustomerFavoriteProduct> continuationResults = await forceClient.QueryContinuationAsync<CustomerFavoriteProduct>(nextRecordsUrl);

                        favoriteList.AddRange(continuationResults.records);

                        if (string.IsNullOrEmpty(continuationResults.nextRecordsUrl)) break;

                        //pass nextRecordsUrl back to client.QueryAsync to request next set of records                    
                        nextRecordsUrl = continuationResults.nextRecordsUrl;
                    }
                }

                if (favoriteList.Count > 0)
                {
                    // pass list object in the form of json string
                    string jsonLocation = JsonConvert.SerializeObject(favoriteList);

                    Intent intent = new Intent(this, typeof(FavoriteProductActivity));
                    intent.PutExtra("FavoriteData", jsonLocation);
                    StartActivity(intent);
                }
            };

        }
    }
}