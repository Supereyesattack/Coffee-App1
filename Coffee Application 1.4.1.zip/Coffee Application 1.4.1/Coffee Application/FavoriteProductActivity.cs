/* Screen     : Top Favorite Products Ordered From All Stores
*  Description: Shows top favorite products based on orders
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Coffee_Application.DataModel;
using Salesforce.Common.Models;
using Newtonsoft.Json;

namespace Coffee_Application
{
    [Activity(Label = "@string/ApplicationName")]
    public class FavoriteProductActivity : Activity
    {
        public CustomListAdapter listAdapter;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            string json = Intent.GetStringExtra("FavoriteData") ?? null;
            List<CustomList> items = new List<CustomList>();

            if (json != null)
            {
                // convert json string back to a list object
                var favoriteList = JsonConvert.DeserializeObject<List<CustomerFavoriteProduct>>(json);

                for (int i = 0; i < favoriteList.Count; i++)
                {
                    CustomList item = new CustomList();
                    item.Name = favoriteList[i].Name;
                    items.Add(item);
                }
            }

            //// Create your application here
            //SetContentView(Resource.Layout.CustomListItem);

            ////Create our adapter
            //listAdapter = new CustomListAdapter(this, items);

            ////Find the listview reference
            //var listView = FindViewById<ListView>(Resource.Id.FavoriteProductListView);

            ////Hook up our adapter to our ListView
            //listView.Adapter = listAdapter;

            //// Get our button from the layout resource,
            //// and attach an event to it
            //Button returnMenuButton = FindViewById<Button>(Resource.Id.ReturnMenuButton);
            //returnMenuButton.Enabled = false;

            //returnMenuButton.Click += delegate
            //{
            //    Intent intent = new Intent(this, typeof(MenuSelectionActivity));
            //    StartActivity(intent);
            //};

        }
    }
}