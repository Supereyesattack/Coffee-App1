using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

using Coffee_Application.DataModel;
using Newtonsoft.Json;
using Salesforce.Common;
using Salesforce.Common.Models;
using Salesforce.Force;

namespace Coffee_Application.Conroller
{

    public class ApplicationService
    {

        // The following are from Salesforce configuration, needed for authentication
        // This is using OAuth Authentication
        private static string consumerKey = "3MVG9fMtCkV6eLhfrqYgIEUifLDXx6ztdUXjsHXkVDL81lmI7ZYlmmPG0We1mJYBQlq5yl3_doyZKXWgoVpVs";
        private static string consumerSecret = "8718126830326927672";
        private static string url = "https://login.salesforce.com/services/oauth2/token";
        //

        private static AuthenticationClient AuthClient = new AuthenticationClient();

        // This is the method that calls for authentication
        public async Task<bool> AuthenticateClient(string username, string password)
        {
            //create auth client to retrieve token
            var authTask = AuthClient.UsernamePasswordAsync(consumerKey, consumerSecret, username, password, url);
            try
            {
                await authTask;
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public async Task<List<LoginUser>> GetLoginUser(string username, string password)
        {

            List<LoginUser> loginUserList = new List<LoginUser>();

            Task<bool> clientTask = AuthenticateClient(username, password);

            // await! control returns to the caller
            bool clientIsAuthenticated = await clientTask;

            if (clientIsAuthenticated && AuthClient.Id != null)
            {
                ForceClient forceClient = new ForceClient(AuthClient.InstanceUrl, AuthClient.AccessToken,
                    AuthClient.ApiVersion);

                var soqlLoginString =
                    string.Format(
                        "SELECT Id, Name, Username, Total_Rewards__c, Street, City, State, PostalCode, Country, Email, Phone FROM User WHERE Username = '{0}'",
                        username);

                try
                {
                    // Retrieve the login user info from Salesforce
                    QueryResult<LoginUser> results = await forceClient.QueryAsync<LoginUser>(soqlLoginString);

                    loginUserList.AddRange(results.records);

                    var nextRecordsUrl = results.nextRecordsUrl;

                    if (!string.IsNullOrEmpty(nextRecordsUrl))
                    {
                        while (true)
                        {
                            QueryResult<LoginUser> continuationResults =
                                await forceClient.QueryContinuationAsync<LoginUser>(nextRecordsUrl);

                            loginUserList.AddRange(continuationResults.records);

                            if (string.IsNullOrEmpty(continuationResults.nextRecordsUrl)) break;

                            //pass nextRecordsUrl back to client.QueryAsync to request next set of records                    
                            nextRecordsUrl = continuationResults.nextRecordsUrl;
                        }
                    }
                }
                catch (Exception)
                {
                    //return "Loading error! Please try again.";

                }

                if (loginUserList.Count > 0)
                {
                    Global.UserId = loginUserList[0].Id;
                    Global.Name = loginUserList[0].Name;
                    Global.ForceClient = forceClient;
                }

            }

            return loginUserList;
            //return JsonConvert.SerializeObject(loginUserList);
        }

    }
}