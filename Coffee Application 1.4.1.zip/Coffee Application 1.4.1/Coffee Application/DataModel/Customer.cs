/* Class: List for Users/Customers
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace Coffee_Application.DataModel
{
    public class Customer
    {
        public const String SObjectTypeName = "User";
        public String Id { get; set; }
        public String Name { get; set; }
        public String Total_Rewards__c { get; set; }
        public String Street { get; set; }
        public String City { get; set; }
        public String State { get; set; }
        public String Country { get; set; }
        public String PostalCode { get; set; }
        public String Phone { get; set; }
        public String Email { get; set; }
    }
}