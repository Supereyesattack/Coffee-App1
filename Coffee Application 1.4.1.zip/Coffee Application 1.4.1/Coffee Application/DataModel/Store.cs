/* Class: List of Stores
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace Coffee_Application.DataModel
{
    public class Store
    {
        public const String SObjectTypeName = "Account";
        public String Id { get; set; }
        public String Name { get; set; }
        public String ParentId { get; set; }
        public int Image { get; set; }
    }
}